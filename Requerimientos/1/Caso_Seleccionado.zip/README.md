# Sistema de Registro de Usuarios

## Descripción
Aplicación que permite registrar y autenticar usuarios mediante correo electrónico y contraseña.

## Objetivos
- Facilitar el registro y acceso de usuarios.
- Garantizar seguridad y manejo de datos personales.
- Sistema escalable y mantenible.

## Requerimientos Funcionales
1. Registro de nuevos usuarios.
2. Validación de correos duplicados.
3. Inicio de sesión seguro.

## Requerimientos No Funcionales
- Interfaz amigable y responsiva.
- Encriptación de contraseñas.
- Tiempo de respuesta < 3s.

## Plan de Pruebas

| N° | Caso de Prueba | Resultado Esperado | Validación |
|----|----------------|--------------------|-------------|
| 1 | Registro exitoso | Usuario registrado correctamente | ✅ |
| 2 | Registro duplicado | Mensaje 'Correo ya registrado' | ✅ |
| 3 | Inicio de sesión | Acceso exitoso al sistema | ✅ |

## Tipo de Mantenimiento
**Perfectivo** – Mejora de interfaz y autenticación multifactor (MFA).

## Reflexión sobre control de versiones
El uso de Git y GitHub permite mantener un historial claro de cambios, revertir errores y trabajar en equipo de forma eficiente.
