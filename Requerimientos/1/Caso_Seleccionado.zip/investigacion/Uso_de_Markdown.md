# Uso de Markdown en proyectos de software

## ¿Qué es Markdown?
Markdown es un lenguaje de marcado ligero para dar formato al texto de manera simple.

## ¿Por qué se utiliza?
Porque facilita la documentación técnica legible sin herramientas complejas.

## Ejemplo práctico
```markdown
# Encabezado 1
## Encabezado 2
- Lista de elementos
1. Paso 1
2. Paso 2

| Nombre | Edad |
|--------|------|
| Ana | 25 |
| Luis | 30 |

![Logo ejemplo](https://upload.wikimedia.org/wikipedia/commons/9/91/Octicons-mark-github.svg)
[Ir a GitHub](https://github.com)
```

## Ventajas de usar Markdown + GitHub
- Integración directa con repositorios.
- Facilita documentación colaborativa.
- Control de versiones en textos técnicos.
- Compatible con muchas herramientas.
