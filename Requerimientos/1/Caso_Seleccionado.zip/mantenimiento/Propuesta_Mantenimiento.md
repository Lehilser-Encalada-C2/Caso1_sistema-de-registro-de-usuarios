# Propuesta de Mantenimiento Perfectivo

**Tipo:** Perfectivo  
**Objetivo:** Mejorar la experiencia de usuario añadiendo autenticación multifactor (MFA) y una interfaz moderna.

## Actividades
- Actualizar la interfaz gráfica (HTML/CSS/JS).
- Implementar verificación de dos pasos con correo o SMS.
- Probar compatibilidad en dispositivos móviles.
- Documentar cambios en el README y commits.
